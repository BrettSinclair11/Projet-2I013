// ### WORLD OF CELLS ###
// created by nicolas.bredeche(at)upmc.fr
// date of creation: 2013-1-12

package applications.simpleworld;

import java.util.ArrayList;

import javax.media.opengl.GL2;

import objects.UniqueDynamicObject;

import worlds.World;

public abstract class Agent extends UniqueDynamicObject{
	
	protected final int[] WorldSize = super.world.getWorldSize();
	
	protected String ID;
	
	protected int HP, SpotRange, FoodRange, WaterRange, TotalFood, TotalWater, Food, Water, Stamina, TotalStamina, Souffle;
	
	protected int [] position = this.getCoordinate();
	
	protected float Direction;
	
	protected ArrayList<Agent> Predators;
	
	protected ArrayList<Agent> Preys;
	
	protected ArrayList<Agent> buffer;
	
	public Agent(int __x , int __y, World __world) {
		
		super(__x,__y,__world);
		
		buffer= new ArrayList<Agent>();
		
		for(UniqueDynamicObject agent : super.world.getUniqueDynamicObjects()) {
			buffer.add((Agent) agent);
		}
	}

	public void step() {
		
		for(Agent agent : buffer) {
			
			agent.Preys = agent.getPreys(agent.ID);
			agent.Predators = agent.getPredators(agent.ID);
			
			this.Souffle = Math.min(this.Souffle + 1, 10);
			
			if(agent.Burn()) {
				continue;
			}
			
			agent.Eat();
			
			if (agent.CanDrink()
					&& agent.isPredator(position) == null) {
				
				Drink();
			}
			
			if (agent.ID== "COW") agent.Food = Math.max((agent.Food - (int) ((float) agent.TotalFood / 40.f)), 0);
			
			if (agent.ID== "Raptor") agent.Food = Math.max((agent.Food - (int) ((float) agent.TotalFood / 100.f)), 0);
			
			if (agent.ID== "TRex") 	agent.Food = Math.max((agent.Food - (int) ((float) agent.TotalFood / 100.f)), 0);
			
			if(agent.Water - agent.TotalWater / 50 < 0) {
				super.world.getUniqueDynamicObjects().remove(this);
			}else {
				agent.Water = Math.max(agent.Water - agent.TotalWater / 50, 0);
			}
			
			if (agent.Food / 1.f * agent.TotalFood >= 0.5
				&& agent.Water / 1.f * agent.TotalWater >= 0.5
				&& agent.isPredator(position) == null) {
				
				agent.HP = Math.min(agent.HP + agent.TotalFood / 8, agent.TotalFood);
			}
			
			if (agent.Food / 1.f * agent.TotalFood <= 0.2
					|| agent.Water / 1.f * agent.TotalWater <= 0.2) {
					
				agent.HP = Math.max(agent.HP - agent.TotalFood / 20, 0);
			}
			
			if(agent.HP <= 0) {
				
				super.world.getUniqueDynamicObjects().remove(agent);
			}
			
			boolean modified = false;

			if 		(agent.Water / 1.f * agent.TotalWater 	<= 0.5) {
				modified = agent.FindWater() || modified;
			
			}else if (agent.Food / 1.f * agent.TotalFood <= 0.5) {
				modified = agent.FindFood()  || modified;
			
			}

			
			modified = agent.AvoidDanger() || modified;

			agent.Move(modified);
		}
		buffer= new ArrayList<Agent>();
		
		for(UniqueDynamicObject agent : super.world.getUniqueDynamicObjects()) {
			buffer.add((Agent) agent);
		}
	}
	
	public void Move(boolean modified) {

		float TempDirection = this.Direction;

		if (!modified) {
			
			this.Stamina = Math.min(this.Stamina + 5, this.TotalStamina);
			
			float r = (float) Math.random();

			if (r < 0.3) TempDirection = (TempDirection - 0.25f) % 1.f;
			if (r > 0.6) TempDirection = (TempDirection + 0.25f) % 1.f;
		
			if (TempDirection == 0.f) 	this.y = (this.y + 1 + WorldSize[1]) % WorldSize[1];
			if (TempDirection == 0.25f) this.x = (this.x + 1 + WorldSize[0]) % WorldSize[0];
			if (TempDirection == 0.5f) 	this.y = (this.y - 1 + WorldSize[1]) % WorldSize[1];
			if (TempDirection == 0.75f) this.x = (this.x - 1 + WorldSize[0]) % WorldSize[0];
		
		}else if (this.Stamina >= 5 && this.Souffle == 10) {
			
			this.Stamina = Math.max(this.Stamina - 5, 0);
			if (this.Stamina <= 0) this.Souffle = 0;
			
			if (TempDirection == 0.f) 	this.y = (this.y + 2 + WorldSize[1]) % WorldSize[1];
			if (TempDirection == 0.25f) this.x = (this.x + 2 + WorldSize[0]) % WorldSize[0];
			if (TempDirection == 0.5f) 	this.y = (this.y - 2 + WorldSize[1]) % WorldSize[1];
			if (TempDirection == 0.75f) this.x = (this.x - 2 + WorldSize[0]) % WorldSize[0];
		
		}else
			this.Stamina = Math.min(this.Stamina + 5, this.TotalStamina);
	}

	public boolean AvoidDanger() {

		float InitialDirection = this.Direction;
		boolean modified = false;
		for(int i = this.x - this.SpotRange; i <= this.x + this.SpotRange; i ++) {
			for(int j = this.y - this.SpotRange; j <= this.y + this.SpotRange; j ++) {
				
				if (this.Direction == (InitialDirection - 0.25f) % 1.f) break;

				if (	 (this.Direction == 0.f 	 && j >= this.y)
						|| (this.Direction == 0.25f  && i >= this.x)
						|| (this.Direction == 0.5f 	 && j <= this.x)
						|| (this.Direction == 0.75f  && i <= this.x)) {
					
					int[] pos= {(i + WorldSize[0]) % WorldSize[0], (j + WorldSize[1]) % WorldSize[1]};
					
					if (((super.world.getCellValue2((i + WorldSize[0]) % WorldSize[0], (j + WorldSize[1]) % WorldSize[1]) == 7
						|| super.world.getCellValue((i + WorldSize[0]) % WorldSize[0], (j + WorldSize[1]) % WorldSize[1]) == 2 
						|| super.world.getCellValue1((i + WorldSize[0]) % WorldSize[0], (j + WorldSize[1]) % WorldSize[1]) == 5) && Math.abs(this.x - i) + Math.abs(this.y - j) <= this.SpotRange)
							|| (this.isPredator(pos) != null && Math.abs(this.x - i) + Math.abs(this.y - j) <= (int) (this.SpotRange * 3.f / 4.f))) {
						
						this.Direction = (this.Direction + 0.25f) % 1.f;
						modified = true;
					}
				}
			}
		}
		return modified;
	}

	public abstract boolean FindFood();
	
	public boolean FindWater() {
		
		int minDistance = this.WaterRange;
		boolean modified = false;
		
		for(int i = this.x - this.WaterRange; i <= this.x + this.WaterRange; i ++) {
			for(int j = this.y - this.WaterRange; j <= this.y + this.WaterRange; j ++) {

				if (super.world.getCellValue3((i + WorldSize[0]) % WorldSize[0], (j + WorldSize[1]) % WorldSize[1]) == -1 && Math.abs(this.x - i) + Math.abs(this.y - j) < minDistance) {

					minDistance = Math.abs(this.x - i) + Math.abs(this.y - j);
					modified = true;

					if 		(j >= this.y) this.Direction = 0.f;
					else if (i >= this.x) this.Direction = 0.25f;
					else if (j <= this.x) this.Direction = 0.5f;
					else if (i <= this.x) this.Direction = 0.75f;
				}
			}
		}
		return modified;
	}
	
	public boolean Burn() {
		
		if (super.world.getCellValue2(x, y) == 7
			|| super.world.getCellValue5(x, y) == 11) {
			
			super.world.getUniqueDynamicObjects().remove(this);
			return true;
		}
		
		if (super.world.getCellValue(x, y) == 2
			|| super.world.getCellValue1(x, y) == 5) {
			
			this.Bleed(15);
			return true;
		}
		return false;
	}
	
	public boolean CanDrink() {
		
		if (   super.world.getCellValue3((x + 1 + WorldSize[0]) % WorldSize[0], y) == -1
			|| super.world.getCellValue3((x - 1 + WorldSize[0]) % WorldSize[0], y) == -1
			|| super.world.getCellValue3(x	  , (y + 1 + WorldSize[1]) % WorldSize[1]) == -1
			|| super.world.getCellValue3(x	  , (y - 1 + WorldSize[1]) % WorldSize[1]) == -1
			|| super.world.isRaining()) {
			
			return true;
		}
		return false;
	}
	
	public void Drink() {
		
		this.Water = Math.min(this.Water + this.TotalWater / 4, this.TotalWater);
	}
	
	public void Eat() {
		
		if (this.ID == "COW"
			&& super.world.getCellValue1(x, y) == 4
			&& isPredator(position) == null
			&& this.TotalFood - this.Food >= this.TotalFood / 40) {
			
			this.Food = Math.min(this.Food + this.TotalFood / 10, this.TotalFood);
			super.world.setCellValue1(x, y, 0);
		
		}else if (this.ID == "Raptor") {
			
			if (this.isPrey(position) != null
				&& isPredator(position) == null
				&& this.TotalFood - this.Food >= this.TotalFood / 100) {
				
				this.Food = Math.min(this.Food + this.TotalFood / 4, this.TotalFood);
				this.isPrey(position).Bleed(TotalFood / 4);
			}
		
		}else {
			
			if (this.isPrey(position) != null
				&& isPredator(position) == null
				&& this.TotalFood - this.Food >= this.TotalFood / 100) {
					
				if(this.isPrey(position).ID== "COW") {
					
					this.Food = Math.min(this.Food + 150, this.TotalFood);
					this.isPrey(position).Bleed(150);
				
				}else {
				
					this.Food = Math.min(this.Food + 100, this.TotalFood);
					this.isPrey(position).Bleed(100);
				}
			}	
		}
	}
	
	public void Bleed(int i) {
		
		this.HP -= i;
		if (this.HP <= 0) {
			
			super.world.getUniqueDynamicObjects().remove(this);
		}
	}
	
	public ArrayList<Agent> getPredators(String name) {
		
		ArrayList<Agent> Predators = new ArrayList<Agent>();
		
		for(UniqueDynamicObject agent : super.world.getUniqueDynamicObjects()) {
			
			if (name == "COW") {
				
				if (!(agent instanceof Cow)) Predators.add((Agent) agent);
			}
			else if (name == "Raptor") {
				
				if (agent instanceof TRex) Predators.add((Agent) agent);
			
			}else {
				
				if (agent instanceof TRex) Predators.add((Agent) agent);
			}
		}
		return Predators;
	}
	
	public ArrayList<Agent> getPreys(String name) {
		
		ArrayList<Agent> Preys = new ArrayList<Agent>();
		
		for(UniqueDynamicObject agent : super.world.getUniqueDynamicObjects()) {
			
			if (name == "Raptor")
				if (agent instanceof Cow) Preys.add((Agent) agent);
			
			else if (name == "TRex") Preys.add((Agent) agent);
		}
		return Preys;
	}
	
	public Agent isPredator(int[] position) {
		
		for(Agent agent: this.Predators)
			if (agent.position == position) return agent;
			
		return null;
	}
	
	public Agent isPrey(int[] position) {
		
		for(Agent agent: this.Preys)
			if (agent.position == position) return agent;
			
		return null;
	}

	public abstract void displayUniqueObject(World myWorld, GL2 gl, int offsetCA_x,
		int offsetCA_y, float offset, float stepX, float stepY, float lenX, float lenY, float normalizeHeight);
}
