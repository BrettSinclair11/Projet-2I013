package objects;

import javax.media.opengl.GL2;

import worlds.World;

public class Rain extends CommonObject {
	 public static void displayObjectAt(World myWorld, GL2 gl, int cellState, float x, float y, double height, float offset, float stepX, float stepY, float lenX, float lenY, float normalizeHeight ) {
		 
		 if (myWorld.isRaining()) {
			 	/*
			 	gl.glEnable(GL2.GL_COLOR_MATERIAL);
			 	gl.glColor4f(0.f, 0.f, 1.0f, 0.3f);
	    	 
	    	 	float altitude = (float)height * normalizeHeight ;
	    		
	    		//float heightFactor, double heightBooster, float smoothFactor[]
	    		
	    	
	    		float i = 60.f;
	    	
	    		while(i >= altitude + 10.f) {
	    			
	    			if (myWorld.getIteration() % 2 == (x + y) % 4) {
	    			
	    			gl.glVertex3f( offset+x*stepX, offset+y*stepY, i);
	    			gl.glVertex3f( offset+x*stepX, offset+y*stepY, i - 1.f);
	    			
	    			}
	    			else {
	    			
	    			gl.glVertex3f( offset+x*stepX, offset+y*stepY, i - 1.f);
	    			gl.glVertex3f( offset+x*stepX, offset+y*stepY, i - 2.f);
	    			
	    			}
	    			
	    			i -= 8;
	    		}
	    		*/
		 }
	 }
}
