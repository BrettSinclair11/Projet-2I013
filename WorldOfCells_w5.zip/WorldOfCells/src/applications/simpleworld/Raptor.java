// ### WORLD OF CELLS ###
// created by nicolas.bredeche(at)upmc.fr
// date of creation: 2013-1-12

package applications.simpleworld;

import javax.media.opengl.GL2;

import objects.UniqueDynamicObject;

import worlds.World;

public class Raptor extends Agent {

	public Raptor ( int __x , int __y, World __world )
	{
		super(__x,__y,__world);
	}

	public void displayUniqueObject(World myWorld, GL2 gl, int offsetCA_x,
			int offsetCA_y, float offset, float stepX, float stepY, float lenX, float lenY, float normalizeHeight)
	{


			//gl.glColor3f(0.f+(float)(0.5*Math.random()),0.f+(float)(0.5*Math.random()),0.f+(float)(0.5*Math.random()));

		int x2 = (x-(offsetCA_x%myWorld.getWidth()));
		if ( x2 < 0) x2 += myWorld.getWidth();
		int y2 = (y-(offsetCA_y%myWorld.getHeight()));
		if ( y2 < 0) y2 += myWorld.getHeight();

		float height = Math.max ( 0 , (float)myWorld.getCellHeight(x, y) );


				//Display a TORRAP


			//Queue


		gl.glColor3f(91.f / 250.f, 60.f / 250.f, 17.f / 250.f);
		gl.glVertex3f( offset + x2 * stepX - 5.f * lenX, offset + y2 * stepY + 0.f * lenY, height * normalizeHeight + 1.f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 3.f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 3.f);

		gl.glColor3f(91.f / 250.f, 60.f / 250.f, 17.f / 250.f);
		gl.glVertex3f( offset + x2 * stepX - 5.f * lenX, offset + y2 * stepY + 0.f * lenY, height * normalizeHeight + 1.f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 4.f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 3.f);

		gl.glColor3f(91.f / 250.f, 60.f / 250.f, 17.f / 250.f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 3.f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 4.f);
		gl.glVertex3f( offset + x2 * stepX - 5.f * lenX, offset + y2 * stepY + 0.f * lenY, height * normalizeHeight + 1.f);

		gl.glColor3f(91.f / 250.f, 60.f / 250.f, 17.f / 250.f);
		gl.glVertex3f( offset + x2 * stepX - 5.f * lenX, offset + y2 * stepY + 0.f * lenY, height * normalizeHeight + 1.f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 4.f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 4.f);


			//Corps arriere

		//Dessous
		gl.glColor3f(91.f / 250.f, 60.f / 250.f, 17.f / 250.f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 3.f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 3.375f);
		gl.glVertex3f( offset + x2 * stepX + 0.5f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 3.375f);
		gl.glVertex3f( offset + x2 * stepX + 0.5f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 3.f);

		gl.glColor3f(91.f / 250.f, 60.f / 250.f, 17.f / 250.f);
		gl.glVertex3f( offset + x2 * stepX + 0.5f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 3.375f);
		gl.glVertex3f( offset + x2 * stepX + 0.5f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 3.5f);
		gl.glVertex3f( offset + x2 * stepX + 1.f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 3.5f);
		gl.glVertex3f( offset + x2 * stepX + 1.f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 3.375f);

		//Dessus
		gl.glColor3f(91.f / 250.f, 60.f / 250.f, 17.f / 250.f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 4.5f);
		gl.glVertex3f( offset + x2 * stepX - 1.f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 4.875f);
		gl.glVertex3f( offset + x2 * stepX + 0.5f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 4.875f);
		gl.glVertex3f( offset + x2 * stepX + 0.5f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 4.5f);

		gl.glColor3f(91.f / 250.f, 60.f / 250.f, 17.f / 250.f);
		gl.glVertex3f( offset + x2 * stepX + 0.5f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 4.875f);
		gl.glVertex3f( offset + x2 * stepX + 0.5f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 5.f);
		gl.glVertex3f( offset + x2 * stepX + 1.f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 5.f);
		gl.glVertex3f( offset + x2 * stepX + 1.f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 4.875f);

		//lateral droit
		gl.glColor3f(91.f / 250.f, 60.f / 250.f, 17.f / 250.f);
		gl.glVertex3f( offset + x2 * stepX - 0.5f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 4.625f);
		gl.glVertex3f( offset + x2 * stepX + 2.f * lenX, offset + y2 * stepY + 0.5f * lenY, height * normalizeHeight + 5.25f);
		gl.glVertex3f( offset + x2 * stepX + 2.f * lenX, offset + y2 * stepY + 0.5f * lenY, height * normalizeHeight + 4.f);
		gl.glVertex3f( offset + x2 * stepX + 0.75f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 3.5f);
		gl.glVertex3f( offset + x2 * stepX + 0.75f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 4.25f);
		gl.glVertex3f( offset + x2 * stepX + 0.5f * lenX, offset + y2 * stepY + 0.75f * lenY, height * normalizeHeight + 4.5f);

		//lateral gauche
		gl.glColor3f(91.f / 250.f, 60.f / 250.f, 17.f / 250.f);
		gl.glVertex3f( offset + x2 * stepX + 2.f * lenX, offset + y2 * stepY - 0.5f * lenY, height * normalizeHeight + 4.f);
		gl.glVertex3f( offset + x2 * stepX + 2.f * lenX, offset + y2 * stepY - 0.5f * lenY, height * normalizeHeight + 5.25f);
		gl.glVertex3f( offset + x2 * stepX - 0.5f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 4.625f);
		gl.glVertex3f( offset + x2 * stepX + 0.5f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 4.5f);
		gl.glVertex3f( offset + x2 * stepX + 0.75f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 4.25f);
		gl.glVertex3f( offset + x2 * stepX + 0.75f * lenX, offset + y2 * stepY - 0.75f * lenY, height * normalizeHeight + 3.5f);

	}
}
