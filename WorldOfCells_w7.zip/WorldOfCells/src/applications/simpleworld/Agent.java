// ### WORLD OF CELLS ###
// created by nicolas.bredeche(at)upmc.fr
// date of creation: 2013-1-12

package applications.simpleworld;

import javax.media.opengl.GL2;

import objects.UniqueDynamicObject;

import worlds.World;

public abstract class Agent extends UniqueDynamicObject{

	protected String ID;

	protected int HP, SpotRange, FoodRange, WaterRange, TotalFood, TotalWater, Food, Water;

	protected float Direction;

	protected boolean Alive;

	public String GetID() {

		return this.ID;
	}

	public boolean AvoidDanger() {

		float InitialDirection = this.Direction;
		boolean modified = false;

		for(int i = this.x - this.SpotRange; i <= this.x + this.SpotRange; i ++) {
			for(int j = this.y - this.SpotRange; j <= this.y + this.SpotRange; j ++) {

				if (this.Direction == (InitialDirection - 0.25f) % 1.f) break;

				if (	 (this.Direction == 0.f 	 && j >= this.y)
						|| (this.Direction == 0.25f  && i >= this.x)
						|| (this.Direction == 0.5f 	 && j <= this.x)
						|| (this.Direction == 0.75f  && i <= this.x)) {

					if ((Lave.getCellState(i, j) == 7 || ForestCA.getCellState(i , j) == 2 && abs(i) + abs(j) <= this.SpotRange)
					 || (this.isPredator(i, j) && abs(i) + abs(j) <= this.SpotRange * 3 / 4)) {

						this.Direction = (this.Direction + 0.25f) % 1.f;
						modified = true;
					}
				}
			}
		}
		return modified;
	}

	public boolean FindFood() {

		int minDistance = this.FoodRange;
		boolean modified = false;

		for(int i = this.x - this.FoodRange; i <= this.x + this.FoodRange; i ++) {
			for(int j = this.y - this.FoodRange; j <= this.y + this.FoodRange; j ++) {

				if (GrassCA.getCellState(i, j) == 4 && abs(i) + abs(j) < minDistance) {

					minDistance = abs(i) + abs(j);
					modified = true;

					if 			(j >= this.y) this.Direction = 0.f;
					else if (i >= this.x) this.Direction = 0.25f;
					else if (j <= this.x) this.Direction = 0.5f;
					else if (i <= this.x) this.Direction = 0.75f;
				}
			}
		}
		return modified;
	}

	public boolean FindWater() {

		int minDistance = this.WaterRange;
		boolean modified = false;

		for(int i = this.x - this.WaterRange; i <= this.x + this.WaterRange; i ++) {
			for(int j = this.y - this.WaterRange; j <= this.y + this.WaterRange; j ++) {

				if (EauCA.getCellState(i, j) == -1 && abs(i) + abs(j) < minDistance) {

					minDistance = abs(i) + abs(j);
					modified = true;

					if 			(j >= this.y) this.Direction = 0.f;
					else if (i >= this.x) this.Direction = 0.25f;
					else if (j <= this.x) this.Direction = 0.5f;
					else if (i <= this.x) this.Direction = 0.75f;
				}
			}
		}
		return modified;
	}

	public void Move(boolean modified) {

		float TempDirection = this.Direction;

		if (!modified) {

			float r = Math.random();

			if (r < 0.3) TempDirection = (TempDirection - 0.25f) % 1.f;
			if (r > 0.6) TempDirection = (TempDirection + 0.25f) % 1.f;
		}

		if (TempDirection == 0.f) this.y += 1;
		if (TempDirection == 0.25f) this.x += 1;
		if (TempDirection == 0.5f) this.y -= 1;
		if (TempDirection == 0.75f) this.x -= 1;
	}

	public void step() {

		if (this.Alive) {
			
			//bouffer ou boire si bonne case -> affecte potentiellement d'autres agents si proie/preda

			modified = false;

			if 			(this.Water / TotalWater <= 0.6) 		modified = modified || this.FindWater();
			else if (this.Food / this.TotalFood <= 0.5) modified = modified || this.FindFood();

			modified = modified || this.AvoidDanger();

			this.Move(modified);
		}
	}

  public abstract void displayUniqueObject(World myWorld, GL2 gl, int offsetCA_x,
		int offsetCA_y, float offset, float stepX, float stepY, float lenX, float lenY, float normalizeHeight);
}
